-- Remove old template tables
DROP TABLE ehr.template CASCADE;
DROP TABLE ehr.template_heading_xref CASCADE;
DROP TABLE ehr.template_meta CASCADE;