EHRbase openEHR Server 
Copyright 2018-2019 Vitasystems GmbH and Hannover Medical School.

This product includes software developed by the EHRbase team, 
working for Vitasystems GmbH and Hannover Medical School.

This software contains code and derived code from EtherCIS (ethercis.org) 
which has been developed by Christian Chevalley (ADOC Software Development Co.,Ltd).  
Dr. Tony Shannon and Phil Berret of the Ripple Foundation CIC Ltd, UK (https://ripple.foundation/) and
Dr. Ian McNicoll (FreshEHR Ltd.) greatly contributed as well.